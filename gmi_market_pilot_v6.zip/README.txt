Replace only official_pilot.py in repository root. Run existing Test Official Articles workflow. Pilot does not modify reports.json. Dates and classifications remain provisional. No paid API.
